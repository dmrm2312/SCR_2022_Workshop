#pragma once

#ifndef SENSOR_H
  #define SENSOR_H
#endif

#define FILTER_UPDATE_RATE_HZ 100
#define PRINT_EVERY_N_UPDATES 10

class CarSensors {
    public:
        CarSensors(){};
        
        void setupIMU();
        double getYaw();
        double getPitch();
        double getRoll();
        void filterIMU();

        void setupLidar();
        int getLidarDistance();
        void runLidar();
};
