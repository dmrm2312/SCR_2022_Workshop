// Jillian Pantig - LEMUR Team Arnhold SURP 2021
// Code for Origami Car Robots: Actuation and Feedback Control
//Command.cpp

#include <Adafruit_PWMServoDriver.h>
#include "Command.h"

Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver();

void CommandServo::setupServo()
{
    pwm.begin();
    pwm.setOscillatorFrequency(27000000);
    pwm.setPWMFreq(SERVO_FREQ);  
}

//pwm.setPWM(servochannel, on, off) 
//TREAT MIN AS CW (Clockwise) AND MAX AS CCW (Counterclockwise)

/*
 * The servo channel will depend on how the servos are setup in the car (using Adafruit PWM/Servo Motor FeatherWing)
 * Below is the current setup for this code
           FRONT
    servo1      servo0
           BODY
    servo2      Servo3
           REAR

*/

//Move the car to the left
void CommandServo::left(){
  pwm.setPWM(0, 0, midpoint[0] + (SERVOMINPWM - midpoint[0]));
  pwm.setPWM(1, 0, midpoint[1] + (SERVOMINPWM - midpoint[1]));
  pwm.setPWM(2, 0, midpoint[2] + (SERVOMINPWM - midpoint[2]));
  pwm.setPWM(3, 0, midpoint[3] + (SERVOMINPWM - midpoint[3]));
}

//Move the car to the right
void CommandServo::right(){
  pwm.setPWM(0, 0, midpoint[0] + (SERVOMAXPWM - midpoint[0]));
  pwm.setPWM(1, 0, midpoint[1] + (SERVOMAXPWM - midpoint[1]));
  pwm.setPWM(2, 0, midpoint[2] + (SERVOMAXPWM - midpoint[2]));
  pwm.setPWM(3, 0, midpoint[3] + (SERVOMAXPWM - midpoint[3]));
}

//Stops the car (MIDPOINT can also be used)
void CommandServo::stopS(){
  pwm.setPWM(1, 0, 0);
  pwm.setPWM(0, 0, 0);
  pwm.setPWM(2, 0, 0);
  pwm.setPWM(3, 0, 0);
}

//f = front; b = back
//cw = clockwise
//ccw = counterclockwise

//Using PWM pulse
//Most of the time (NOT ALWAYS), 290-300 is the midpoint (or stop) -- TEST THIS
//Anything > 290-300 will turn the continous servos ccw
//Anything < 290-300 will turn the continous servos cw
void CommandServo::adjustSpeedPWM(int fRight, int fLeft, int bRight, int bLeft){
  pwm.setPWM(0, 0, fRight); //Front right wheel
  pwm.setPWM(1, 0, fLeft); //Front left wheel
  pwm.setPWM(2, 0, bLeft); //Bottom left wheel
  pwm.setPWM(3, 0, bRight); //Bottom right wheel
}

//250 is considered 90 degrees in the SG90 Servo
void CommandServo::steerPWM(float rotate){
      pwm.setPWM(4, 0, rotate);
}

void CommandServo::midpointCalib(int servoNum, int midpoint){
     pwm.setPWM(servoNum, 0, midpoint);
  }
