// Jillian Pantig - LEMUR Team Arnhold SURP 2021
// Code for Origami Car Robots: Actuation and Feedback Control
//Command.h

#pragma once

#ifndef COMMAND_H
  #define COMMAND_H
#endif

//PWM SERVO VALUES - Note that the values below varies on the servo you are using
//The default servos of the Differential and Pivoting Origami Car Robots are FS90R Continous Servo Motors
#define MIDPOINTPWM 290 //IMPORTANT: Midpoint will vary on every motor and will NEVER be accurate. Adjust using the dash or adjust here.
#define SERVOMINPWM  205 //For the current purpose of the car, this is the 'minimum' pulse length count (out of 4096)
#define SERVOMAXPWM  375 //For the current purpose of the car, This is the 'maximum' pulse length count (out of 4096)

#define SERVO_FREQ 50 // Analog servos run at ~50 Hz

class CommandServo {
    public:      
        int midpoint[5]; //Midpoint for the Continuous Servo Motors
        CommandServo(){
          for(int i = 0; i < 4; ++i)
            midpoint[i] = MIDPOINTPWM;
            midpoint[4] = 250; //This is the midpoint of the standard servo of the hinge on the pivoting car
          };
        void setupServo(); 
        void stopS(); //HARD STOP ALL OF THE CONTINOUS SERVO MOTORS
        void forward(); //Moves them forward
        void left(); //Moves them to the left 
        void right(); //Moves them to the right 
        void adjustSpeedPWM(int fRight, int fLeft, int bRight, int bLeft); //Runs the motors in relation to the arguments
        void midpointCalib(int servoNum, int midpoint); //Used for calibrating midpoint of each servos
        void steerPWM(float loopIter); //Used for rotating (0-180) the standard servo in the hinge of the pivoting car to go to a certain direction
};
